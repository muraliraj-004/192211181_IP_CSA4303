/**line 1 */
const section1 = document.getElementById("section1");
const section1_header = document.getElementById("section1_header");

section1_header.addEventListener("mouseover", function(ev) {
    section1.style.display = "block";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});


/**line 2 */
const section2 = document.getElementById("section2");
const section2_header = document.getElementById("section2_header");

section2_header.addEventListener("mouseover", function(ev) {
    section2.style.display = "block";
    section1.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";

});
/**line 3  */
const section3 = document.getElementById("section3");
const section3_header = document.getElementById("section3_header");

section3_header.addEventListener("mouseover", function(ev) {
    section3.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});
/**line 4 */
const section4 = document.getElementById("section4");
const section4_header = document.getElementById("section4_header");

section4_header.addEventListener("mouseover", function(ev) {
    section4.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});


/**line 5 */
const section5 = document.getElementById("section5");
const section5_header = document.getElementById("section5_header");

section5_header.addEventListener("mouseover", function(ev) {
    section5.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});

/**line 6 */
const section6 = document.getElementById("section6");
const section6_header = document.getElementById("section6_header");

section6_header.addEventListener("mouseover", function(ev) {
    section6.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});


/**line 7 */
const section7 = document.getElementById("section7");
const section7_header = document.getElementById("section7_header");

section7_header.addEventListener("mouseover", function(ev) {
    section7.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});

/**line 8 */
const section8 = document.getElementById("section8");
const section8_header = document.getElementById("section8_header");

section8_header.addEventListener("mouseover", function(ev) {
    section8.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});

/**line 9 */
const section9 = document.getElementById("section9");
const section9_header = document.getElementById("section9_header");

section9_header.addEventListener("mouseover", function(ev) {
    section9.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});

/**line 10 */
const section10 = document.getElementById("section10");
const section10_header = document.getElementById("section10_header");

section10_header.addEventListener("mouseover", function(ev) {
    section10.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section11.style.display = "none";
    section12.style.display = "none";
});

/**line 11 */
const section11 = document.getElementById("section11");
const section11_header = document.getElementById("section11_header");

section11_header.addEventListener("mouseover", function(ev) {
    section11.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section12.style.display = "none";
});

/**line 8 */
const section12 = document.getElementById("section12");
const section12_header = document.getElementById("section12_header");

section12_header.addEventListener("mouseover", function(ev) {
    section12.style.display = "block";
    section1.style.display = "none";
    section2.style.display = "none";
    section3.style.display = "none";
    section4.style.display = "none";
    section5.style.display = "none";
    section6.style.display = "none";
    section7.style.display = "none";
    section8.style.display = "none";
    section9.style.display = "none";
    section10.style.display = "none";
    section11.style.display = "none";
});