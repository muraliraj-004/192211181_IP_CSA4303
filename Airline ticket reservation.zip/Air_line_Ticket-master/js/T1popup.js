function togglePopup(){
  document.getElementById("popup-1").classList.toggle("active");
}